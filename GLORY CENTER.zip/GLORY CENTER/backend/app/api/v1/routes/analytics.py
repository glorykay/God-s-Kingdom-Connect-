from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from app.db.session import get_db
from app.api.v1.dependencies import get_current_user, get_current_church
from app.schemas.analytics import (
    WeeklyAnalyticsResponse,
    MonthlyAnalyticsResponse,
    YearlyAnalyticsResponse,
    TotalAnalyticsResponse,
)
from app.services_layer.analytics_service import AnalyticsService

router = APIRouter(
    prefix="/analytics",
    tags=["Analytics"]
)


# -----------------------------
# WEEKLY ANALYTICS
# -----------------------------
@router.get("/weekly/{church_id}", response_model=WeeklyAnalyticsResponse)
def get_weekly_analytics(
    church_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
    church=Depends(get_current_church)
):
    analytics = AnalyticsService(db)
    return analytics.get_weekly(church_id)


# -----------------------------
# MONTHLY ANALYTICS
# -----------------------------
@router.get("/monthly/{church_id}", response_model=MonthlyAnalyticsResponse)
def get_monthly_analytics(
    church_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
    church=Depends(get_current_church)
):
    analytics = AnalyticsService(db)
    return analytics.get_monthly(church_id)


# -----------------------------
# YEARLY ANALYTICS
# -----------------------------
@router.get("/yearly/{church_id}", response_model=YearlyAnalyticsResponse)
def get_yearly_analytics(
    church_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
    church=Depends(get_current_church)
):
    analytics = AnalyticsService(db)
    return analytics.get_yearly(church_id)


# -----------------------------
# TOTAL ANALYTICS (ALL TIME)
# -----------------------------
@router.get("/total/{church_id}", response_model=TotalAnalyticsResponse)
def get_total_analytics(
    church_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
    church=Depends(get_current_church)
):
    analytics = AnalyticsService(db)
    return analytics.get_total(church_id)
