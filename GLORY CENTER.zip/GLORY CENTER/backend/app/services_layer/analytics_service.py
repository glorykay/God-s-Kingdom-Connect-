from sqlalchemy.orm import Session
from sqlalchemy import func, extract
from datetime import datetime

from app.models.attendance import Attendance
from app.models.service import Service


class AnalyticsService:
    def __init__(self, db: Session):
        self.db = db

    # -----------------------------
    # WEEKLY ANALYTICS
    # -----------------------------
    def get_weekly(self, church_id: int):
        current_year = datetime.utcnow().year

        weekly_data = (
            self.db.query(
                extract("week", Attendance.timestamp).label("week"),
                func.count(Attendance.id).label("count")
            )
            .join(Service, Attendance.service_id == Service.id)
            .filter(Service.church_id == church_id)
            .filter(extract("year", Attendance.timestamp) == current_year)
            .group_by("week")
            .order_by("week")
            .all()
        )

        return {
            "year": current_year,
            "weekly": [{"week": w.week, "count": w.count} for w in weekly_data]
        }

    # -----------------------------
    # MONTHLY ANALYTICS
    # -----------------------------
    def get_monthly(self, church_id: int):
        current_year = datetime.utcnow().year

        monthly_data = (
            self.db.query(
                extract("month", Attendance.timestamp).label("month"),
                func.count(Attendance.id).label("count")
            )
            .join(Service, Attendance.service_id == Service.id)
            .filter(Service.church_id == church_id)
            .filter(extract("year", Attendance.timestamp) == current_year)
            .group_by("month")
            .order_by("month")
            .all()
        )

        return {
            "year": current_year,
            "monthly": [{"month": m.month, "count": m.count} for m in monthly_data]
        }

    # -----------------------------
    # YEARLY ANALYTICS
    # -----------------------------
    def get_yearly(self, church_id: int):
        yearly_data = (
            self.db.query(
                extract("year", Attendance.timestamp).label("year"),
                func.count(Attendance.id).label("count")
            )
            .join(Service, Attendance.service_id == Service.id)
            .filter(Service.church_id == church_id)
            .group_by("year")
            .order_by("year")
            .all()
        )

        return {
            "years": [{"year": y.year, "count": y.count} for y in yearly_data]
        }

    # -----------------------------
    # TOTAL ANALYTICS (ALL TIME)
    # -----------------------------
    def get_total(self, church_id: int):
        total_attendance = (
            self.db.query(func.count(Attendance.id))
            .join(Service, Attendance.service_id == Service.id)
            .filter(Service.church_id == church_id)
            .scalar()
        )

        total_services = (
            self.db.query(func.count(Service.id))
            .filter(Service.church_id == church_id)
            .scalar()
        )

        return {
            "total_attendance": total_attendance,
            "total_services": total_services
        }
