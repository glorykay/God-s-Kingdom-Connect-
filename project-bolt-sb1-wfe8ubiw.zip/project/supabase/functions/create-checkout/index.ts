import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const PRICE_ID = "price_1QzYAmGc5cXcXcXcXcXcXcXc"; // placeholder — replaced below

async function getOrCreatePrice(stripeKey: string): Promise<string> {
  // Check if a product+price already exists for this app
  const res = await fetch("https://api.stripe.com/v1/prices?active=true&type=recurring&limit=100", {
    headers: { Authorization: `Bearer ${stripeKey}` },
  });
  const data = await res.json();
  const existing = data.data?.find((p: { nickname: string | null }) => p.nickname === "Glory Center Monthly");
  if (existing) return existing.id;

  // Create product + price
  const productRes = await fetch("https://api.stripe.com/v1/products", {
    method: "POST",
    headers: { Authorization: `Bearer ${stripeKey}` },
    body: new URLSearchParams({ name: "Glory Center Monthly Subscription" }),
  });
  const product = await productRes.json();

  const priceRes = await fetch("https://api.stripe.com/v1/prices", {
    method: "POST",
    headers: { Authorization: `Bearer ${stripeKey}` },
    body: new URLSearchParams({
      product: product.id,
      currency: "usd",
      "unit_amount": "1499",
      "recurring[interval]": "month",
      nickname: "Glory Center Monthly",
    }),
  });
  const price = await priceRes.json();
  return price.id;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const stripeKey = Deno.env.get("STRIPE_SECRET_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!stripeKey || !supabaseUrl || !supabaseServiceKey) {
      return new Response(JSON.stringify({ error: "Server not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const userClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: userData } = await userClient.auth.getUser();
    if (!userData.user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = userData.user.id;
    const email = userData.user.email ?? "";

    // Find workspace owned by this user
    const { data: ws } = await supabase
      .from("workspaces")
      .select("*")
      .eq("owner_user_id", userId)
      .maybeSingle();

    if (!ws) {
      return new Response(JSON.stringify({ error: "No workspace found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get or create Stripe customer
    let customerId = ws.stripe_customer_id;

    if (!customerId) {
      const customerRes = await fetch("https://api.stripe.com/v1/customers", {
        method: "POST",
        headers: { Authorization: `Bearer ${stripeKey}` },
        body: new URLSearchParams({
          email,
          metadata: { workspace_id: ws.id },
        }),
      });
      const customer = await customerRes.json();
      customerId = customer.id;

      await supabase
        .from("workspaces")
        .update({ stripe_customer_id: customerId })
        .eq("id", ws.id);
    }

    const priceId = await getOrCreatePrice(stripeKey);
    const origin = req.headers.get("origin") ?? "http://localhost:5173";

    const checkoutRes = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: { Authorization: `Bearer ${stripeKey}` },
      body: new URLSearchParams({
        mode: "subscription",
        customer: customerId,
        "line_items[0][price]": priceId,
        "line_items[0][quantity]": "1",
        success_url: `${origin}/?checkout=success`,
        cancel_url: `${origin}/?checkout=cancelled`,
        metadata: JSON.stringify({ workspace_id: ws.id }),
        "subscription_data[metadata][workspace_id]": ws.id,
      }),
    });

    const session = await checkoutRes.json();

    if (session.error) {
      return new Response(JSON.stringify({ error: session.error.message }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ url: session.url }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: "Internal server error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
