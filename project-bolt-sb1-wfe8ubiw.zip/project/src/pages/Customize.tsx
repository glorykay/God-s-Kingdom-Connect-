import { useEffect, useState, useRef } from 'react';
import { useCustomization, FONT_OPTIONS } from '@/context/CustomizationContext';
import { useLanguage } from '@/context/LanguageContext';
import { useWorkspace } from '@/context/WorkspaceContext';
import { supabase } from '@/lib/supabase';
import {
  Palette,
  Type,
  Image as ImageIcon,
  LayoutDashboard,
  LayoutGrid,
  List,
  Monitor,
  Sun,
  Moon,
  Church,
  Check,
  Upload,
  Save,
  RotateCcw,
  Eye,
  Sparkles,
} from 'lucide-react';

const COLOR_PRESETS = [
  { name: 'Amber', primary: '#f59e0b', accent: '#3b82f6', bg: '#f8fafc' },
  { name: 'Emerald', primary: '#10b981', accent: '#6366f1', bg: '#f0fdf4' },
  { name: 'Blue', primary: '#3b82f6', accent: '#f59e0b', bg: '#eff6ff' },
  { name: 'Rose', primary: '#f43f5e', accent: '#0ea5e9', bg: '#fff1f2' },
  { name: 'Teal', primary: '#14b8a6', accent: '#f97316', bg: '#f0fdfa' },
  { name: 'Indigo', primary: '#6366f1', accent: '#ec4899', bg: '#eef2ff' },
  { name: 'Orange', primary: '#f97316', accent: '#06b6d4', bg: '#fff7ed' },
  { name: 'Cyan', primary: '#06b6d4', accent: '#8b5cf6', bg: '#ecfeff' },
];

const CHURCH_THEMES = [
  { name: 'Royal', color1: '#1e3a8a', color2: '#3b82f6' },
  { name: 'Sanctuary', color1: '#78350f', color2: '#f59e0b' },
  { name: 'Garden', color1: '#14532d', color2: '#22c55e' },
  { name: 'Sunset', color1: '#7c2d12', color2: '#f97316' },
  { name: 'Grace', color1: '#581c87', color2: '#c026d3' },
  { name: 'Ocean', color1: '#0c4a6e', color2: '#0ea5e9' },
];

export function Customize() {
  const { customization, loading, save } = useCustomization();
  const { workspace } = useWorkspace();
  const { t } = useLanguage();
  const [savingField, setSavingField] = useState<string | null>(null);
  const [logoInput, setLogoInput] = useState('');
  const [showReset, setShowReset] = useState(false);
  const [uploadingLogo, setUploadingLogo] = useState(false);

  useEffect(() => {
    if (customization?.logo_url) setLogoInput(customization.logo_url);
  }, [customization?.logo_url]);

  async function updateField(field: string, value: string | null) {
    if (!customization) return;
    setSavingField(field);
    await save({ [field]: value } as Record<string, string | null>);
    setSavingField(null);
  }

  function applyPreset(preset: typeof COLOR_PRESETS[0]) {
    updateField('primary_color', preset.primary);
    updateField('accent_color', preset.accent);
    updateField('bg_color', preset.bg);
  }

  function applyChurchTheme(theme: typeof CHURCH_THEMES[0]) {
    updateField('church_theme_name', theme.name);
    updateField('church_theme_color1', theme.color1);
    updateField('church_theme_color2', theme.color2);
    updateField('theme_mode', 'church');
  }

  function resetAll() {
    save({
      logo_url: null,
      primary_color: '#f59e0b',
      accent_color: '#3b82f6',
      bg_color: '#f8fafc',
      font_family: 'Inter',
      sidebar_style: 'dark',
      dashboard_template: 'classic',
      card_layout: 'grid',
      theme_mode: 'system',
      church_theme_name: null,
      church_theme_color1: null,
      church_theme_color2: null,
    });
    setShowReset(false);
  }

  const fileInputRef = useRef<HTMLInputElement>(null);

  async function handleLogoUpload(file: File) {
    if (!workspace) return;
    setUploadingLogo(true);
    const ext = file.name.split('.').pop()?.toLowerCase() || 'png';
    const fileName = `${workspace.id}/logo-${Date.now()}.${ext}`;
    const { error } = await supabase.storage
      .from('church-logos')
      .upload(fileName, file, { cacheControl: '3600', upsert: true });
    if (!error) {
      const { data: urlData } = supabase.storage.from('church-logos').getPublicUrl(fileName);
      const publicUrl = urlData.publicUrl;
      setLogoInput(publicUrl);
      await updateField('logo_url', publicUrl);
    }
    setUploadingLogo(false);
  }

  if (loading || !customization) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-3 border-amber-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles size={24} className="text-amber-500" />
            {t('customize.title')}
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{t('customize.subtitle')}</p>
        </div>
        <button
          onClick={() => setShowReset(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
        >
          <RotateCcw size={16} /> {t('customize.reset')}
        </button>
      </div>

      {/* Live Preview Banner */}
      <div className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700" style={{ background: customization.bg_color }}>
        <div className="p-5 flex items-center gap-4">
          {customization.logo_url ? (
            <img src={customization.logo_url} alt="Logo" className="w-14 h-14 rounded-xl object-cover" />
          ) : (
            <div
              className="w-14 h-14 rounded-xl flex items-center justify-center shadow-lg"
              style={{ background: `linear-gradient(135deg, ${customization.primary_color}, ${customization.accent_color})` }}
            >
              <Church size={26} className="text-white" />
            </div>
          )}
          <div>
            <h2 className="font-bold text-lg" style={{ color: customization.primary_color, fontFamily: customization.font_family }}>
              {workspace?.name ?? 'Glory Center'}
            </h2>
            <p className="text-sm text-slate-500" style={{ fontFamily: customization.font_family }}>
              {t('customize.preview')}
            </p>
          </div>
          <span className="ml-auto text-xs font-medium px-3 py-1.5 rounded-full" style={{ background: customization.primary_color + '20', color: customization.primary_color }}>
            <Eye size={12} className="inline mr-1" /> {t('customize.livePreview')}
          </span>
        </div>
      </div>

      {/* Logo Section */}
      <SectionCard icon={<ImageIcon size={20} />} title={t('customize.logoTitle')}>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png,image/jpeg,image/jpg,image/webp,image/svg+xml"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) handleLogoUpload(file);
            e.target.value = '';
          }}
        />
        <div className="flex items-center gap-4 mb-4">
          {customization.logo_url ? (
            <img src={customization.logo_url} alt="Logo preview" className="w-20 h-20 rounded-2xl object-cover border border-slate-200 dark:border-slate-700" />
          ) : (
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={uploadingLogo}
              className="w-20 h-20 rounded-2xl bg-slate-100 dark:bg-slate-700 flex items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-600 hover:border-amber-500 dark:hover:border-amber-500 transition-colors group"
            >
              {uploadingLogo ? (
                <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
              ) : (
                <Upload size={24} className="text-slate-400 group-hover:text-amber-500 transition-colors" />
              )}
            </button>
          )}
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploadingLogo}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium text-white bg-amber-500 hover:bg-amber-600 disabled:opacity-50 transition-colors"
              >
                <Upload size={14} />
                {uploadingLogo ? 'Uploading...' : 'Upload Image'}
              </button>
              <span className="text-xs text-slate-400">or paste a URL below</span>
            </div>
            <input
              value={logoInput}
              onChange={(e) => setLogoInput(e.target.value)}
              onBlur={() => updateField('logo_url', logoInput.trim() || null)}
              className="form-input"
              placeholder="https://example.com/church-logo.png"
            />
            <p className="text-xs text-slate-400 mt-1.5">{t('customize.logoHint')}</p>
          </div>
        </div>
        {customization.logo_url && (
          <button
            onClick={() => { setLogoInput(''); updateField('logo_url', null); }}
            className="text-xs text-rose-500 font-medium hover:underline"
          >
            {t('customize.removeLogo')}
          </button>
        )}
      </SectionCard>

      {/* Colors Section */}
      <SectionCard icon={<Palette size={20} />} title={t('customize.colorsTitle')}>
        {/* Color Presets */}
        <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">{t('customize.presets')}</p>
        <div className="grid grid-cols-4 sm:grid-cols-8 gap-3 mb-5">
          {COLOR_PRESETS.map((preset) => (
            <button
              key={preset.name}
              onClick={() => applyPreset(preset)}
              className={`group relative rounded-xl p-1 border-2 transition-all ${
                customization.primary_color === preset.primary
                  ? 'border-slate-400 dark:border-slate-500'
                  : 'border-transparent hover:border-slate-200 dark:hover:border-slate-600'
              }`}
            >
              <div
                className="w-full aspect-square rounded-lg flex items-center justify-center"
                style={{ background: `linear-gradient(135deg, ${preset.primary}, ${preset.accent})` }}
              >
                {customization.primary_color === preset.primary && (
                  <Check size={16} className="text-white" />
                )}
              </div>
              <p className="text-[10px] text-center text-slate-400 mt-1">{preset.name}</p>
            </button>
          ))}
        </div>

        {/* Custom Color Pickers */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <ColorPicker
            label={t('customize.primaryColor')}
            value={customization.primary_color}
            onChange={(v) => updateField('primary_color', v)}
            saving={savingField === 'primary_color'}
          />
          <ColorPicker
            label={t('customize.accentColor')}
            value={customization.accent_color}
            onChange={(v) => updateField('accent_color', v)}
            saving={savingField === 'accent_color'}
          />
          <ColorPicker
            label={t('customize.bgColor')}
            value={customization.bg_color}
            onChange={(v) => updateField('bg_color', v)}
            saving={savingField === 'bg_color'}
          />
        </div>
      </SectionCard>

      {/* Fonts Section */}
      <SectionCard icon={<Type size={20} />} title={t('customize.fontsTitle')}>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {FONT_OPTIONS.map((font) => (
            <button
              key={font}
              onClick={() => updateField('font_family', font)}
              className={`px-4 py-3 rounded-xl border-2 text-sm transition-all ${
                customization.font_family === font
                  ? 'border-amber-500 bg-amber-50 dark:bg-amber-500/10'
                  : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
              }`}
              style={{ fontFamily: font }}
            >
              {font}
              {customization.font_family === font && (
                <Check size={14} className="inline ml-1.5 text-amber-500" />
              )}
            </button>
          ))}
        </div>
      </SectionCard>

      {/* Theme Mode Section */}
      <SectionCard icon={<Monitor size={20} />} title={t('customize.themeModeTitle')}>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <ThemeOption
            icon={<Monitor size={18} />}
            label={t('customize.themeSystem')}
            active={customization.theme_mode === 'system'}
            onClick={() => updateField('theme_mode', 'system')}
          />
          <ThemeOption
            icon={<Sun size={18} />}
            label={t('customize.themeLight')}
            active={customization.theme_mode === 'light'}
            onClick={() => updateField('theme_mode', 'light')}
          />
          <ThemeOption
            icon={<Moon size={18} />}
            label={t('customize.themeDark')}
            active={customization.theme_mode === 'dark'}
            onClick={() => updateField('theme_mode', 'dark')}
          />
          <ThemeOption
            icon={<Church size={18} />}
            label={t('customize.themeChurch')}
            active={customization.theme_mode === 'church'}
            onClick={() => updateField('theme_mode', 'church')}
          />
        </div>

        {/* Church Theme Presets */}
        {customization.theme_mode === 'church' && (
          <div className="mt-5 animate-fadeIn">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-2">{t('customize.churchThemes')}</p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {CHURCH_THEMES.map((theme) => (
                <button
                  key={theme.name}
                  onClick={() => applyChurchTheme(theme)}
                  className={`group flex items-center gap-3 px-4 py-3 rounded-xl border-2 transition-all ${
                    customization.church_theme_name === theme.name
                      ? 'border-slate-400 dark:border-slate-500'
                      : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
                  }`}
                >
                  <div
                    className="w-8 h-8 rounded-lg flex-shrink-0"
                    style={{ background: `linear-gradient(135deg, ${theme.color1}, ${theme.color2})` }}
                  />
                  <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{theme.name}</span>
                  {customization.church_theme_name === theme.name && (
                    <Check size={14} className="ml-auto text-amber-500" />
                  )}
                </button>
              ))}
            </div>

            {/* Custom church theme colors */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
              <ColorPicker
                label={t('customize.themeColor1')}
                value={customization.church_theme_color1 ?? '#1e3a8a'}
                onChange={(v) => updateField('church_theme_color1', v)}
                saving={savingField === 'church_theme_color1'}
              />
              <ColorPicker
                label={t('customize.themeColor2')}
                value={customization.church_theme_color2 ?? '#3b82f6'}
                onChange={(v) => updateField('church_theme_color2', v)}
                saving={savingField === 'church_theme_color2'}
              />
            </div>
          </div>
        )}
      </SectionCard>

      {/* Sidebar Style Section */}
      <SectionCard icon={<LayoutGrid size={20} />} title={t('customize.sidebarTitle')}>
        <div className="grid grid-cols-3 gap-3">
          <StyleOption
            icon={<Moon size={18} />}
            label={t('customize.sidebarDark')}
            active={customization.sidebar_style === 'dark'}
            onClick={() => updateField('sidebar_style', 'dark')}
            preview="bg-slate-900"
          />
          <StyleOption
            icon={<Sun size={18} />}
            label={t('customize.sidebarLight')}
            active={customization.sidebar_style === 'light'}
            onClick={() => updateField('sidebar_style', 'light')}
            preview="bg-slate-100"
          />
          <StyleOption
            icon={<Sparkles size={18} />}
            label={t('customize.sidebarGradient')}
            active={customization.sidebar_style === 'gradient'}
            onClick={() => updateField('sidebar_style', 'gradient')}
            preview="bg-gradient-to-br from-slate-900 to-slate-700"
          />
        </div>
      </SectionCard>

      {/* Dashboard Template Section */}
      <SectionCard icon={<LayoutDashboard size={20} />} title={t('customize.dashboardTitle')}>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
          {[
            { id: 'classic', icon: <LayoutGrid size={16} />, preview: 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-600' },
            { id: 'compact', icon: <List size={16} />, preview: 'bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-600' },
            { id: 'minimal', icon: <Eye size={16} />, preview: 'bg-white dark:bg-slate-800' },
            { id: 'modern', icon: <Sparkles size={16} />, preview: 'bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-500/10 dark:to-blue-500/5' },
            { id: 'gradient', icon: <Palette size={16} />, preview: 'bg-gradient-to-br from-amber-400 to-rose-400' },
            { id: 'corporate', icon: <LayoutDashboard size={16} />, preview: 'bg-slate-100 dark:bg-slate-700 border-l-4 border-blue-500' },
            { id: 'bold', icon: <Type size={16} />, preview: 'bg-slate-900 dark:bg-black border-2 border-amber-500' },
            { id: 'elegant', icon: <Church size={16} />, preview: 'bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-500/10 dark:to-pink-500/5' },
            { id: 'dark', icon: <Moon size={16} />, preview: 'bg-slate-800 dark:bg-black border border-slate-600' },
            { id: 'glass', icon: <Monitor size={16} />, preview: 'bg-white/60 dark:bg-slate-800/40 border border-white/30' },
            { id: 'neumorphic', icon: <LayoutGrid size={16} />, preview: 'bg-slate-200 dark:bg-slate-700 shadow-inner' },
            { id: 'card', icon: <LayoutGrid size={16} />, preview: 'bg-white dark:bg-slate-800 shadow-lg border border-slate-100' },
            { id: 'magazine', icon: <Type size={16} />, preview: 'bg-white dark:bg-slate-800 border-t-4 border-rose-500' },
            { id: 'widget', icon: <LayoutDashboard size={16} />, preview: 'bg-slate-50 dark:bg-slate-900 border border-dashed border-slate-300' },
            { id: 'hero', icon: <Sparkles size={16} />, preview: 'bg-gradient-to-r from-emerald-400 to-teal-500' },
            { id: 'split', icon: <List size={16} />, preview: 'bg-white dark:bg-slate-800 border-r-4 border-blue-500' },
            { id: 'sidebar', icon: <LayoutGrid size={16} />, preview: 'bg-slate-100 dark:bg-slate-800 border-l-4 border-emerald-500' },
            { id: 'tabs', icon: <LayoutDashboard size={16} />, preview: 'bg-white dark:bg-slate-800 border-b-2 border-amber-500' },
            { id: 'banner', icon: <Sparkles size={16} />, preview: 'bg-gradient-to-r from-amber-400 to-orange-500' },
            { id: 'minimalist_pro', icon: <Eye size={16} />, preview: 'bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700' },
          ].map((tpl) => (
            <button
              key={tpl.id}
              onClick={() => updateField('dashboard_template', tpl.id)}
              className={`flex flex-col items-center gap-2 px-2 py-3 rounded-xl border-2 transition-all ${
                customization.dashboard_template === tpl.id
                  ? 'border-amber-500 bg-amber-50 dark:bg-amber-500/10'
                  : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
              }`}
            >
              <div className={`w-full h-12 rounded-lg flex items-center justify-center ${tpl.preview}`}>
                <span className={customization.dashboard_template === tpl.id ? 'text-amber-500' : 'text-slate-400'}>{tpl.icon}</span>
              </div>
              <span className={`text-[10px] font-medium text-center leading-tight ${customization.dashboard_template === tpl.id ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'}`}>
                {t(`customize.template_${tpl.id}`)}
              </span>
            </button>
          ))}
        </div>
        <p className="text-xs text-slate-400 mt-3">{t('customize.templateHint')}</p>
      </SectionCard>

      {/* Card Layout Section */}
      <SectionCard icon={<LayoutGrid size={20} />} title={t('customize.cardLayoutTitle')}>
        <div className="grid grid-cols-2 gap-3">
          <StyleOption
            icon={<LayoutGrid size={18} />}
            label={t('customize.layoutGrid')}
            active={customization.card_layout === 'grid'}
            onClick={() => updateField('card_layout', 'grid')}
            preview="bg-white dark:bg-slate-800"
          />
          <StyleOption
            icon={<List size={18} />}
            label={t('customize.layoutList')}
            active={customization.card_layout === 'list'}
            onClick={() => updateField('card_layout', 'list')}
            preview="bg-slate-50 dark:bg-slate-900"
          />
        </div>
        <p className="text-xs text-slate-400 mt-3">{t('customize.layoutHint')}</p>
      </SectionCard>

      {/* Reset Confirm */}
      {showReset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={() => setShowReset(false)}>
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-500/10 flex items-center justify-center">
                <RotateCcw size={20} className="text-rose-500" />
              </div>
              <h3 className="font-bold text-slate-900 dark:text-white">{t('customize.reset')}</h3>
            </div>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">{t('customize.resetConfirm')}</p>
            <div className="flex gap-3">
              <button onClick={() => setShowReset(false)} className="flex-1 px-4 py-2.5 rounded-xl text-sm font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                {t('common.cancel')}
              </button>
              <button onClick={resetAll} className="flex-1 px-4 py-2.5 rounded-xl text-sm font-medium text-white bg-rose-500 hover:bg-rose-600 transition-colors">
                {t('customize.reset')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SectionCard({ icon, title, children }: { icon: React.ReactNode; title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-500/10 flex items-center justify-center text-amber-600 dark:text-amber-400">
          {icon}
        </div>
        <h2 className="font-bold text-slate-900 dark:text-white text-sm">{title}</h2>
      </div>
      {children}
    </div>
  );
}

function ColorPicker({ label, value, onChange, saving }: { label: string; value: string; onChange: (v: string) => void; saving: boolean }) {
  return (
    <div>
      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">{label}</label>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-10 h-10 rounded-lg border border-slate-200 dark:border-slate-600 cursor-pointer flex-shrink-0"
        />
        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="form-input flex-1 font-mono text-xs"
        />
        {saving && <Save size={14} className="text-amber-500 animate-pulse flex-shrink-0" />}
      </div>
    </div>
  );
}

function ThemeOption({ icon, label, active, onClick }: { icon: React.ReactNode; label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-2 px-4 py-4 rounded-xl border-2 transition-all ${
        active
          ? 'border-amber-500 bg-amber-50 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400'
          : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-600'
      }`}
    >
      {icon}
      <span className="text-xs font-medium">{label}</span>
    </button>
  );
}

function StyleOption({ icon, label, active, onClick, preview }: { icon: React.ReactNode; label: string; active: boolean; onClick: () => void; preview: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-2 px-4 py-4 rounded-xl border-2 transition-all ${
        active
          ? 'border-amber-500 bg-amber-50 dark:bg-amber-500/10'
          : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600'
      }`}
    >
      <div className={`w-full h-12 rounded-lg ${preview} border border-slate-200 dark:border-slate-600 flex items-center justify-center`}>
        <span className={active ? 'text-amber-500' : 'text-slate-400'}>{icon}</span>
      </div>
      <span className={`text-xs font-medium ${active ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500 dark:text-slate-400'}`}>{label}</span>
    </button>
  );
}
