import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { Workspace } from '@/types';
import { Church, Check, Loader2, HandHeart, BookOpen } from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';
import { getRandomVerse } from '@/data/bibleVerses';

interface MemberCheckInProps {
  workspace: Workspace;
  onDone: () => void;
}

export function MemberCheckIn({ workspace, onDone }: MemberCheckInProps) {
  const { t } = useLanguage();
  const [form, setForm] = useState({
    first_name: '',
    last_name: '',
    phone: '',
    email: '',
    address: '',
    prayer_request: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');
  const hadPrayerRequest = form.prayer_request.trim().length > 0;
  const verse = useMemo(() => getRandomVerse(), [success]);

  useEffect(() => {
    document.title = `Check In — ${workspace.name}`;
  }, [workspace.name]);

  async function handleSubmit() {
    if (!form.first_name.trim() || !form.last_name.trim()) {
      setError(t('checkin.errNameRequired'));
      return;
    }
    setSubmitting(true);
    setError('');

    const wid = workspace.id;

    // 1. Create member record
    const { data: newMember, error: memErr } = await supabase.from('members').insert({
      first_name: form.first_name.trim(),
      last_name: form.last_name.trim(),
      phone: form.phone.trim() || null,
      email: form.email.trim() || null,
      address: form.address.trim() || null,
      is_new_comer: true,
      workspace_id: wid,
    }).select().single();

    if (memErr) {
      setError(t('checkin.errGeneric'));
      setSubmitting(false);
      return;
    }

    // 2. Create attendance record (link to nearest upcoming service or standalone)
    const { data: services } = await supabase
      .from('services')
      .select('id')
      .eq('workspace_id', wid)
      .order('service_date', { ascending: true })
      .limit(1);

    await supabase.from('attendance').insert({
      service_id: services?.[0]?.id ?? null,
      member_id: newMember?.id ?? null,
      is_new_comer: true,
      newcomer_name: `${form.first_name.trim()} ${form.last_name.trim()}`,
      workspace_id: wid,
    });

    // 3. Create prayer request if provided
    if (form.prayer_request.trim()) {
      await supabase.from('prayer_requests').insert({
        member_name: `${form.first_name.trim()} ${form.last_name.trim()}`,
        request_text: form.prayer_request.trim(),
        status: 'pending',
        is_private: false,
        workspace_id: wid,
      });
    }

    setSubmitting(false);
    setSuccess(true);
  }

  function resetForm() {
    setForm({ first_name: '', last_name: '', phone: '', email: '', address: '', prayer_request: '' });
    setSuccess(false);
    onDone();
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
        <div className="w-full max-w-md text-center">
          <div className="inline-flex w-20 h-20 rounded-full bg-emerald-500 items-center justify-center mb-6 shadow-2xl shadow-emerald-500/30 animate-slideUp">
            <Check size={40} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white mb-2">{t('checkin.checkinComplete')}</h1>
          <p className="text-slate-400 text-sm mb-6">
            {t('checkin.thankYou', { name: form.first_name, church: workspace.name })}
          </p>

          {hadPrayerRequest && (
            <div className="bg-white/5 dark:bg-white/5 rounded-2xl border border-amber-500/20 p-5 mb-6 text-left">
              <div className="flex items-center gap-2 mb-3">
                <BookOpen size={16} className="text-amber-400" />
                <p className="text-xs font-semibold text-amber-400 uppercase tracking-wide">{t('checkin.verseForYou')}</p>
              </div>
              <p className="text-sm text-slate-200 leading-relaxed italic mb-3">"{verse.text}"</p>
              <p className="text-xs font-semibold text-amber-400 text-right">— {verse.reference}</p>
              <div className="mt-4 pt-4 border-t border-white/10">
                <p className="text-xs text-slate-400">{t('checkin.prayerAcknowledged')}</p>
              </div>
            </div>
          )}

          <button
            onClick={resetForm}
            className="px-6 py-3 rounded-xl bg-amber-500 text-white font-medium text-sm hover:bg-amber-600 transition-colors"
          >
            {t('common.done')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 items-center justify-center shadow-2xl shadow-amber-500/20 mb-3">
            <Church size={28} className="text-slate-900" />
          </div>
          <h1 className="text-xl font-bold text-white">{workspace.name}</h1>
          <p className="text-slate-400 text-sm mt-1">{t('checkin.memberCheckin')}</p>
        </div>

        {/* Form */}
        <div className="bg-white dark:bg-slate-800 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-700 p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">{t('checkin.firstName')}</label>
              <input
                value={form.first_name}
                onChange={(e) => setForm({ ...form, first_name: e.target.value })}
                className="form-input"
                placeholder="John"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">{t('checkin.lastName')}</label>
              <input
                value={form.last_name}
                onChange={(e) => setForm({ ...form, last_name: e.target.value })}
                className="form-input"
                placeholder="Doe"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">{t('checkin.phoneNumber')}</label>
            <input
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              className="form-input"
              placeholder="+1 234 567 890"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">{t('checkin.emailAddress')}</label>
            <input
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="form-input"
              placeholder="john@example.com"
              type="email"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">{t('checkin.homeAddress')}</label>
            <input
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              className="form-input"
              placeholder="123 Main St, City"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1 flex items-center gap-1">
              <HandHeart size={12} className="text-rose-500" />
              {t('checkin.prayerRequest')}
            </label>
            <textarea
              value={form.prayer_request}
              onChange={(e) => setForm({ ...form, prayer_request: e.target.value })}
              className="form-input"
              rows={3}
              placeholder={t('checkin.prayerPlaceholder')}
            />
          </div>

          {error && <p className="text-sm text-red-500">{error}</p>}

          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-sm font-medium text-white bg-amber-500 hover:bg-amber-600 disabled:opacity-50 transition-colors"
          >
            {submitting ? (
              <>
                <Loader2 size={18} className="animate-spin" /> {t('checkin.submitting')}
              </>
            ) : (
              t('checkin.submitCheckin')
            )}
          </button>
        </div>

        <p className="text-center text-xs text-slate-500 mt-4">
          {t('checkin.infoGoesTo')}
        </p>
      </div>
    </div>
  );
}
