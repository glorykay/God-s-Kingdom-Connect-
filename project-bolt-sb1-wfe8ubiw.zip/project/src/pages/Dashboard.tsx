import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/context/WorkspaceContext';
import { useCustomization } from '@/context/CustomizationContext';
import { Member, Service, PrayerRequest, Attendance, PageId } from '@/types';
import { TrialBanner } from '@/components/TrialBanner';
import * as XLSX from 'xlsx';
import {
  Users,
  CalendarDays,
  ClipboardCheck,
  HandHeart,
  TrendingUp,
  ArrowRight,
  Clock,
  MapPin,
  Download,
  Printer,
  FileSpreadsheet,
  Flame,
  AlertTriangle,
  UserCheck,
} from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

interface DashboardProps {
  onNavigate: (page: PageId) => void;
}

interface KPI {
  label: string;
  value: number;
  icon: typeof Users;
  color: string;
  bgColor: string;
  page: PageId;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const { workspace } = useWorkspace();
  const { customization } = useCustomization();
  const { t } = useLanguage();
  const wid = workspace?.id ?? '';
  const [stats, setStats] = useState({
    members: 0,
    services: 0,
    todayAttendance: 0,
    pendingPrayer: 0,
  });
  const [recentMembers, setRecentMembers] = useState<Member[]>([]);
  const [upcomingServices, setUpcomingServices] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);
  const [allMembers, setAllMembers] = useState<Member[]>([]);
  const [allAttendance, setAllAttendance] = useState<Attendance[]>([]);
  const [allPrayers, setAllPrayers] = useState<PrayerRequest[]>([]);
  const [exporting, setExporting] = useState(false);
  const [allServices, setAllServices] = useState<Service[]>([]);

  useEffect(() => {
    if (wid) loadDashboard();
  }, [wid]);

  async function loadDashboard() {
    const [membersRes, servicesRes, attendanceRes, prayerRes, allAttRes] = await Promise.all([
      supabase.from('members').select('*').eq('workspace_id', wid).order('created_at', { ascending: false }),
      supabase.from('services').select('*').eq('workspace_id', wid).order('service_date', { ascending: true }),
      supabase.from('attendance').select('*').eq('workspace_id', wid).gte('timestamp', new Date().toISOString().split('T')[0]),
      supabase.from('prayer_requests').select('*').eq('workspace_id', wid).eq('status', 'pending'),
      supabase.from('attendance').select('*').eq('workspace_id', wid).order('timestamp', { ascending: false }),
    ]);

    setStats({
      members: membersRes.data?.length ?? 0,
      services: servicesRes.data?.length ?? 0,
      todayAttendance: attendanceRes.data?.length ?? 0,
      pendingPrayer: prayerRes.data?.length ?? 0,
    });
    setRecentMembers((membersRes.data ?? []).slice(0, 5));
    setAllMembers(membersRes.data ?? []);
    setAllAttendance(allAttRes.data ?? []);
    setAllServices(servicesRes.data ?? []);
    setAllPrayers(prayerRes.data ?? []);
    setUpcomingServices((servicesRes.data ?? []).filter(s => new Date(s.service_date) >= new Date(new Date().toDateString())).slice(0, 4));
    setLoading(false);
  }

  const template = customization?.dashboard_template ?? 'classic';
  const cardLayout = customization?.card_layout ?? 'grid';
  const brandColor = customization?.primary_color ?? '#f59e0b';
  const accentColor = customization?.accent_color ?? '#3b82f6';
  const logoUrl = customization?.logo_url;

  const isGradientTpl = template === 'gradient' || template === 'hero' || template === 'banner';
  const isDarkTpl = isGradientTpl || template === 'dark' || template === 'bold';
  const headingTextClass = isDarkTpl ? 'text-white' : 'text-slate-900 dark:text-white';
  const subTextClass = isDarkTpl ? 'text-white/60' : 'text-slate-400';
  const nameTextClass = isDarkTpl ? 'text-white' : 'text-slate-900 dark:text-white';
  const linkClass = isDarkTpl ? 'text-white/80 hover:text-white' : 'text-amber-600 dark:text-amber-400';
  const gradientColors = [
    `linear-gradient(135deg, ${brandColor}, ${accentColor})`,
    `linear-gradient(135deg, ${accentColor}, ${brandColor})`,
    `linear-gradient(135deg, ${brandColor}dd, ${accentColor}dd)`,
    `linear-gradient(135deg, ${accentColor}dd, ${brandColor}dd)`,
  ];

  // Template-specific styling for KPI cards
  const tplStyles: Record<string, { kpiGrid: string; kpiCard: string; kpiIcon: string; kpiValue: string; sectionGrid: string; sectionCard: string; headerWrap: string }> = {
    classic:        { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-white dark:bg-slate-800 p-5 border border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-6', sectionCard: 'bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5', headerWrap: '' },
    compact:        { kpiGrid: 'grid grid-cols-2 sm:grid-cols-4 gap-2', kpiCard: 'bg-white dark:bg-slate-800 p-3 border border-slate-200 dark:border-slate-700 hover:border-slate-300', kpiIcon: 'w-9 h-9', kpiValue: 'text-2xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-3', sectionCard: 'bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 p-4', headerWrap: '' },
    minimal:        { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6', kpiCard: 'bg-transparent p-4 border border-transparent hover:border-slate-200 dark:hover:border-slate-700', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-8', sectionCard: 'bg-transparent rounded-2xl p-5', headerWrap: '' },
    modern:         { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-white dark:bg-slate-800 p-5 border-0 rounded-2xl shadow-md hover:shadow-xl', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-white dark:bg-slate-800 rounded-2xl shadow-md p-5', headerWrap: '' },
    gradient:       { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'p-5 border-0 rounded-2xl text-white', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'rounded-2xl p-5 text-white border-0', headerWrap: '' },
    corporate:      { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-slate-50 dark:bg-slate-800 p-5 rounded-xl border-l-4 hover:shadow-md', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-slate-50 dark:bg-slate-800 rounded-xl border-l-4 p-5', headerWrap: '' },
    bold:           { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-slate-900 dark:bg-black p-5 rounded-2xl border-2 border-amber-500 text-white', kpiIcon: 'w-12 h-12', kpiValue: 'text-4xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-slate-900 dark:bg-black rounded-2xl border-2 border-amber-500/50 p-5 text-white', headerWrap: '' },
    elegant:        { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5', kpiCard: 'bg-white dark:bg-slate-800 p-6 rounded-3xl border border-slate-100 dark:border-slate-700', kpiIcon: 'w-14 h-14', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-6', sectionCard: 'bg-white dark:bg-slate-800 rounded-3xl border border-slate-100 dark:border-slate-700 p-6', headerWrap: '' },
    dark:           { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-slate-800 p-5 rounded-2xl border border-slate-700 text-white', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-slate-800 rounded-2xl border border-slate-700 p-5 text-white', headerWrap: '' },
    glass:          { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-white/60 dark:bg-slate-800/40 backdrop-blur-md p-5 rounded-2xl border border-white/40 dark:border-white/10', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-white/60 dark:bg-slate-800/40 backdrop-blur-md rounded-2xl border border-white/40 dark:border-white/10 p-5', headerWrap: '' },
    neumorphic:     { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-slate-100 dark:bg-slate-700 p-5 rounded-2xl shadow-[inset_4px_4px_8px_rgba(0,0,0,0.1)] hover:shadow-[inset_2px_2px_4px_rgba(0,0,0,0.1)]', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-slate-100 dark:bg-slate-700 rounded-2xl shadow-[inset_4px_4px_8px_rgba(0,0,0,0.1)] p-5', headerWrap: '' },
    card:           { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-white dark:bg-slate-800 p-5 rounded-2xl shadow-lg hover:shadow-2xl border border-slate-100 dark:border-slate-700', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-white dark:bg-slate-800 rounded-2xl shadow-lg p-5 border border-slate-100 dark:border-slate-700', headerWrap: '' },
    magazine:       { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-white dark:bg-slate-800 p-5 rounded-2xl border-t-4 border-rose-500', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-white dark:bg-slate-800 rounded-2xl border-t-4 border-rose-500 p-5', headerWrap: '' },
    widget:         { kpiGrid: 'grid grid-cols-2 sm:grid-cols-4 gap-3', kpiCard: 'bg-slate-50 dark:bg-slate-900 p-4 rounded-xl border border-dashed border-slate-300 dark:border-slate-600', kpiIcon: 'w-10 h-10', kpiValue: 'text-2xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-4', sectionCard: 'bg-slate-50 dark:bg-slate-900 rounded-xl border border-dashed border-slate-300 dark:border-slate-600 p-4', headerWrap: '' },
    hero:           { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'p-5 rounded-2xl text-white border-0', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'rounded-2xl p-5 text-white border-0', headerWrap: '' },
    split:          { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-white dark:bg-slate-800 p-5 rounded-2xl border-r-4 border-blue-500', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-white dark:bg-slate-800 rounded-2xl border-r-4 border-blue-500 p-5', headerWrap: '' },
    sidebar:        { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-white dark:bg-slate-800 p-5 rounded-2xl border-l-4 border-emerald-500', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-white dark:bg-slate-800 rounded-2xl border-l-4 border-emerald-500 p-5', headerWrap: '' },
    tabs:           { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'bg-white dark:bg-slate-800 p-5 rounded-2xl border-b-4 border-amber-500', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'bg-white dark:bg-slate-800 rounded-2xl border-b-4 border-amber-500 p-5', headerWrap: '' },
    banner:         { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4', kpiCard: 'p-5 rounded-2xl text-white border-0', kpiIcon: 'w-12 h-12', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-5', sectionCard: 'rounded-2xl p-5 text-white border-0', headerWrap: '' },
    minimalist_pro: { kpiGrid: 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6', kpiCard: 'bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-100 dark:border-slate-700', kpiIcon: 'w-11 h-11', kpiValue: 'text-3xl', sectionGrid: 'grid grid-cols-1 lg:grid-cols-2 gap-6', sectionCard: 'bg-white dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700 p-5', headerWrap: '' },
  };

  const ts = tplStyles[template] ?? tplStyles.classic;

  const kpis: KPI[] = [
    { label: t('dashboard.totalMembers'), value: stats.members, icon: Users, color: 'text-blue-600 dark:text-blue-400', bgColor: 'bg-blue-50 dark:bg-blue-500/10', page: 'members' },
    { label: t('dashboard.services'), value: stats.services, icon: CalendarDays, color: 'text-amber-600 dark:text-amber-400', bgColor: 'bg-amber-50 dark:bg-amber-500/10', page: 'services' },
    { label: t('dashboard.todaysAttendance'), value: stats.todayAttendance, icon: ClipboardCheck, color: 'text-emerald-600 dark:text-emerald-400', bgColor: 'bg-emerald-50 dark:bg-emerald-500/10', page: 'attendance' },
    { label: t('dashboard.pendingPrayers'), value: stats.pendingPrayer, icon: HandHeart, color: 'text-rose-600 dark:text-rose-400', bgColor: 'bg-rose-50 dark:bg-rose-500/10', page: 'prayer' },
  ];

  function exportExcel() {
    setExporting(true);

    const wb = XLSX.utils.book_new();

    // Sheet 1: Members
    const membersData = allMembers.map((m) => ({
      'First Name': m.first_name,
      'Last Name': m.last_name,
      'Email': m.email ?? '',
      'Phone': m.phone ?? '',
      'Address': m.address ?? '',
      'New Comer': m.is_new_comer ? 'Yes' : 'No',
      'Joined Date': new Date(m.joined_date).toLocaleDateString(),
    }));
    const wsMembers = XLSX.utils.json_to_sheet(membersData.length > 0 ? membersData : [{ 'First Name': '', 'Last Name': '', 'Email': '', 'Phone': '', 'Address': '', 'New Comer': '', 'Joined Date': '' }]);
    XLSX.utils.book_append_sheet(wb, wsMembers, 'Members');

    // Sheet 2: Today's Attendance
    const attData = allAttendance.map((a) => ({
      'Name': a.is_new_comer ? a.newcomer_name ?? 'New Comer' : 'Member',
      'New Comer': a.is_new_comer ? 'Yes' : 'No',
      'Time': new Date(a.timestamp).toLocaleString(),
    }));
    const wsAtt = XLSX.utils.json_to_sheet(attData.length > 0 ? attData : [{ 'Name': '', 'New Comer': '', 'Time': '' }]);
    XLSX.utils.book_append_sheet(wb, wsAtt, 'Today Attendance');

    // Sheet 3: Prayer Requests
    const prayerData = allPrayers.map((p) => ({
      'Name': p.member_name,
      'Request': p.request_text,
      'Status': p.status,
      'Date': new Date(p.created_at).toLocaleDateString(),
    }));
    const wsPrayer = XLSX.utils.json_to_sheet(prayerData.length > 0 ? prayerData : [{ 'Name': '', 'Request': '', 'Status': '', 'Date': '' }]);
    XLSX.utils.book_append_sheet(wb, wsPrayer, 'Prayer Requests');

    const fileName = `glory-center-${workspace?.name?.toLowerCase().replace(/\s+/g, '-')}-${new Date().toISOString().split('T')[0]}.xlsx`;
    XLSX.writeFile(wb, fileName);
    setExporting(false);
  }

  function printSheet() {
    const printWin = window.open('', '_blank');
    if (!printWin) return;

    const rows = allMembers.map((m) => `
      <tr>
        <td>${m.first_name}</td>
        <td>${m.last_name}</td>
        <td>${m.email ?? ''}</td>
        <td>${m.phone ?? ''}</td>
        <td>${m.address ?? ''}</td>
        <td>${m.is_new_comer ? 'Yes' : 'No'}</td>
        <td>${new Date(m.joined_date).toLocaleDateString()}</td>
      </tr>`).join('');

    printWin.document.write(`
      <html>
      <head>
        <title>${workspace?.name} — Member Report</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 24px; }
          h1 { font-size: 20px; margin-bottom: 4px; }
          p { color: #666; font-size: 12px; margin-bottom: 16px; }
          table { width: 100%; border-collapse: collapse; font-size: 12px; }
          th { background: #f59e0b; color: white; padding: 8px 10px; text-align: left; }
          td { padding: 6px 10px; border-bottom: 1px solid #e5e7eb; }
          tr:nth-child(even) { background: #f9fafb; }
        </style>
      </head>
      <body>
        <h1>${workspace?.name}</h1>
        <p>Member Report — ${new Date().toLocaleDateString()}</p>
        <table>
          <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Address</th>
              <th>New Comer</th>
              <th>Joined</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
        <script>window.onload = () => window.print()</script>
      </body>
      </html>
    `);
    printWin.document.close();
  }

  // Compute attendance gaps and streaks
  const attendanceGaps = (() => {
    if (allMembers.length === 0 || allServices.length === 0) return [];
    const now = new Date();
    const twoWeeksAgo = new Date(now);
    twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);
    return allMembers
      .filter((m) => !m.is_new_comer || new Date(m.joined_date) < twoWeeksAgo)
      .map((m) => {
        const memberAttendance = allAttendance.filter((a) => a.member_id === m.id);
 const lastAttended = memberAttendance.length > 0 ? new Date(memberAttendance[0].timestamp) : null;
        const daysSinceLast = lastAttended
          ? Math.floor((now.getTime() - lastAttended.getTime()) / (1000 * 60 * 60 * 24))
          : null;
        return { member: m, lastAttended, daysSinceLast };
      })
      .filter((item) => item.daysSinceLast === null || item.daysSinceLast >= 14)
      .sort((a, b) => (b.daysSinceLast ?? 9999) - (a.daysSinceLast ?? 9999))
      .slice(0, 5);
  })();

  const attendanceStreaks = (() => {
    if (allMembers.length === 0 || allServices.length === 0) return [];
    const now = new Date();
    const sortedServices = [...allServices].sort((a, b) => new Date(b.service_date).getTime() - new Date(a.service_date).getTime());
    return allMembers
      .map((m) => {
        const memberAttendance = allAttendance.filter((a) => a.member_id === m.id);
        const attDates = new Set(memberAttendance.map((a) => new Date(a.timestamp).toDateString()));
        let streak = 0;
        for (const s of sortedServices) {
          const sDate = new Date(s.service_date);
          if (sDate > now) continue;
          const serviceDateStr = sDate.toDateString();
          const dayAfter = new Date(sDate);
          dayAfter.setDate(dayAfter.getDate() + 1);
          const dayAfterStr = dayAfter.toDateString();
          if (attDates.has(serviceDateStr) || attDates.has(dayAfterStr)) {
            streak++;
          } else {
            break;
          }
        }
        return { member: m, streak };
      })
      .filter((item) => item.streak >= 2)
      .sort((a, b) => b.streak - a.streak)
      .slice(0, 5);
  })();

  function gapLabel(daysSinceLast: number | null): string {
    if (daysSinceLast === null) return t('gaps.neverAttended');
    if (daysSinceLast >= 60) return t('gaps.monthsAway', { count: Math.floor(daysSinceLast / 30) });
    if (daysSinceLast >= 14) return t('gaps.weeksAway', { count: Math.floor(daysSinceLast / 7) });
    return t('gaps.daysAway', { count: daysSinceLast });
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-3 border-amber-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <TrialBanner />

      <div>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {logoUrl && (
              <img src={logoUrl} alt="Church logo" className="w-12 h-12 rounded-xl object-cover flex-shrink-0" />
            )}
            <div>
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white">{t('dashboard.welcome')} {workspace?.name}</h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{t('dashboard.welcomeSub')}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={exportExcel}
              disabled={exporting}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 text-white font-medium text-sm hover:bg-emerald-700 disabled:opacity-50 transition-colors shadow-lg shadow-emerald-600/20"
            >
              <FileSpreadsheet size={18} /> {exporting ? t('dashboard.exporting') : t('dashboard.exportExcel')}
            </button>
            <button
              onClick={printSheet}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-sm border border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
            >
              <Printer size={18} /> {t('dashboard.print')}
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className={cardLayout === 'list' ? 'grid grid-cols-1 gap-3' : ts.kpiGrid}>
        {kpis.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <button
              key={kpi.label}
              onClick={() => onNavigate(kpi.page)}
              className={`group rounded-2xl hover:shadow-lg transition-all text-left ${ts.kpiCard}`}
              style={isGradientTpl ? { background: gradientColors[idx % gradientColors.length] } : template === 'corporate' ? { borderLeftColor: brandColor } : template === 'bold' ? { borderColor: brandColor } : template === 'tabs' ? { borderBottomColor: brandColor } : undefined}
            >
              <div className="flex items-start justify-between">
                <div className={`${ts.kpiIcon} rounded-xl ${kpi.bgColor} flex items-center justify-center`}>
                  <Icon size={ts.kpiIcon === 'w-9 h-9' ? 18 : ts.kpiIcon === 'w-14 h-14' ? 26 : 22} className={kpi.color} />
                </div>
                <ArrowRight size={18} className={`${isGradientTpl ? 'text-white/60 group-hover:text-white group-hover:translate-x-1' : 'text-slate-300 dark:text-slate-600 group-hover:text-slate-500 group-hover:translate-x-1'} transition-all`} />
              </div>
              <p className={`${ts.kpiValue} font-bold mt-3 ${isGradientTpl ? 'text-white' : 'text-slate-900 dark:text-white'}`}>{kpi.value}</p>
              <p className={`text-sm mt-0.5 ${isGradientTpl ? 'text-white/80' : 'text-slate-500 dark:text-slate-400'}`}>{kpi.label}</p>
            </button>
          );
        })}
      </div>

      <div className={cardLayout === 'list' ? 'grid grid-cols-1 gap-4' : ts.sectionGrid}>
        {/* Recent Members */}
        <div className={`${ts.sectionCard}`} style={isGradientTpl ? { background: gradientColors[0] } : undefined}>
          <div className="flex items-center justify-between mb-4">
            <h2 className={`font-bold ${headingTextClass}`}>{t('dashboard.recentMembers')}</h2>
            <button onClick={() => onNavigate('members')} className={`text-sm font-medium hover:underline ${linkClass}`}>
              {t('dashboard.viewAll')}
            </button>
          </div>
          {recentMembers.length === 0 ? (
            <p className={`text-sm text-center py-8 ${subTextClass}`}>{t('dashboard.noMembers')}</p>
          ) : (
            <div className="space-y-3">
              {recentMembers.map((m) => (
                <div key={m.id} className="flex items-center gap-3 py-2">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white font-semibold text-sm">
                    {m.first_name[0]}{m.last_name[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium truncate ${nameTextClass}`}>{m.first_name} {m.last_name}</p>
                    <p className={`text-xs ${subTextClass}`}>{m.email || m.phone || t('common.noContact')}</p>
                  </div>
                  {m.is_new_comer && (
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400">
                      {t('common.new')}
                    </span>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Upcoming Services */}
        <div className={`${ts.sectionCard}`} style={isGradientTpl ? { background: gradientColors[1] } : undefined}>
          <div className="flex items-center justify-between mb-4">
            <h2 className={`font-bold ${headingTextClass}`}>{t('dashboard.upcomingServices')}</h2>
            <button onClick={() => onNavigate('services')} className={`text-sm font-medium hover:underline ${linkClass}`}>
              {t('dashboard.viewAll')}
            </button>
          </div>
          {upcomingServices.length === 0 ? (
            <p className={`text-sm text-center py-8 ${subTextClass}`}>{t('dashboard.noUpcoming')}</p>
          ) : (
            <div className="space-y-3">
              {upcomingServices.map((s) => (
                <div key={s.id} className="flex items-start gap-3 py-2">
                  <div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-500/10 flex flex-col items-center justify-center flex-shrink-0">
                    <span className="text-[10px] font-medium text-amber-600 dark:text-amber-400 uppercase">
                      {new Date(s.service_date).toLocaleDateString(undefined, { month: 'short' })}
                    </span>
                    <span className="text-base font-bold text-amber-700 dark:text-amber-300">
                      {new Date(s.service_date).getDate()}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium truncate ${nameTextClass}`}>{s.name}</p>
                    <div className="flex items-center gap-3 mt-0.5">
                      <span className={`text-xs flex items-center gap-1 ${subTextClass}`}>
                        <Clock size={12} /> {s.service_time}
                      </span>
                    </div>
                    {s.speaker && <p className={`text-xs mt-0.5 ${subTextClass}`}>{s.speaker}</p>}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Attendance Gaps & Streaks */}
      <div className={cardLayout === 'list' ? 'grid grid-cols-1 gap-4' : ts.sectionGrid}>
        {/* Attendance Gaps */}
        <div className={`${ts.sectionCard}`} style={isGradientTpl ? { background: gradientColors[2] } : undefined}>
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle size={18} className="text-amber-500" />
            <h2 className={`font-bold ${headingTextClass}`}>{t('gaps.title')}</h2>
          </div>
          <p className={`text-xs mb-4 ${subTextClass}`}>{t('gaps.subtitle')}</p>
          {attendanceGaps.length === 0 ? (
            <p className={`text-sm text-center py-8 ${subTextClass}`}>{t('gaps.noGaps')}</p>
          ) : (
            <div className="space-y-3">
              {attendanceGaps.map(({ member, lastAttended, daysSinceLast }) => (
                <div key={member.id} className="flex items-center gap-3 py-2">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
                    {member.first_name[0]}{member.last_name[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium truncate ${nameTextClass}`}>{member.first_name} {member.last_name}</p>
                    <p className={`text-xs ${subTextClass}`}>
                      {t('gaps.lastSeen')}: {lastAttended ? lastAttended.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : t('gaps.neverAttended')}
                    </p>
                  </div>
                  <span className={`text-[10px] font-semibold px-2.5 py-1 rounded-full flex-shrink-0 ${
                    daysSinceLast === null
                      ? 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400'
                      : (daysSinceLast ?? 0) >= 30
                        ? 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400'
                        : 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400'
                  }`}>
                    {gapLabel(daysSinceLast)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Attendance Streaks */}
        <div className={`${ts.sectionCard}`} style={isGradientTpl ? { background: gradientColors[3] } : undefined}>
          <div className="flex items-center gap-2 mb-4">
            <Flame size={18} className="text-orange-500" />
            <h2 className={`font-bold ${headingTextClass}`}>{t('gaps.streakTitle')}</h2>
          </div>
          {attendanceStreaks.length === 0 ? (
            <p className={`text-sm text-center py-8 ${subTextClass}`}>{t('gaps.noStreaks')}</p>
          ) : (
            <div className="space-y-3">
              {attendanceStreaks.map(({ member, streak }) => (
                <div key={member.id} className="flex items-center gap-3 py-2">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
                    {member.first_name[0]}{member.last_name[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-medium truncate ${nameTextClass}`}>{member.first_name} {member.last_name}</p>
                    <p className={`text-xs ${subTextClass}`}>{t('gaps.activeStreak')}</p>
                  </div>
                  <span className="text-[10px] font-semibold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400 flex items-center gap-1 flex-shrink-0">
                    <Flame size={10} />
                    {t('gaps.streakWeeks', { count: streak })}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
