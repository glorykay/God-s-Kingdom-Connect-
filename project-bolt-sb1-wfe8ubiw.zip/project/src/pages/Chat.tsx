import { useState, useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { useWorkspace } from '@/context/WorkspaceContext';
import { ChatMessage } from '@/types';
import {
  Send,
  Paperclip,
  Download,
  Crown,
  Users,
  MessageCircle,
  Loader2,
  FileText,
  Image as ImageIcon,
  File,
  X,
} from 'lucide-react';
import { useLanguage } from '@/context/LanguageContext';

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatTime(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const isToday = d.toDateString() === now.toDateString();
  if (isToday) {
    return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  }
  return d.toLocaleDateString([], { month: 'short', day: 'numeric' }) + ' ' +
    d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
}

function getFileIcon(fileName: string | null) {
  if (!fileName) return File;
  const ext = fileName.split('.').pop()?.toLowerCase();
  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].includes(ext || '')) return ImageIcon;
  return FileText;
}

interface ChatParticipant {
  id: string;
  display_name: string;
  role: string;
}

export function Chat() {
  const { workspace, role, displayName } = useWorkspace();
  const { t } = useLanguage();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [participants, setParticipants] = useState<ChatParticipant[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const loadMessages = useCallback(async () => {
    if (!workspace) return;
    const { data, error: err } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('workspace_id', workspace.id)
      .order('created_at', { ascending: true });

    if (err) {
      setError(t('chat.errLoadMessages'));
      setLoading(false);
      return;
    }

    setMessages((data as ChatMessage[]) ?? []);
    setLoading(false);
    setTimeout(scrollToBottom, 100);
  }, [workspace, scrollToBottom]);

  const loadParticipants = useCallback(async () => {
    if (!workspace) return;
    const { data } = await supabase
      .from('workspace_members')
      .select('id, display_name, role')
      .eq('workspace_id', workspace.id)
      .in('role', ['pastor', 'coordinator'])
      .order('role', { ascending: true });

    setParticipants((data as ChatParticipant[]) ?? []);
  }, [workspace]);

  useEffect(() => {
    loadMessages();
    loadParticipants();
  }, [loadMessages, loadParticipants]);

  // Realtime subscription
  useEffect(() => {
    if (!workspace) return;

    const channel = supabase
      .channel('chat-messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `workspace_id=eq.${workspace.id}`,
        },
        (payload) => {
          const newMsg = payload.new as ChatMessage;
          setMessages((prev) => {
            if (prev.some((m) => m.id === newMsg.id)) return prev;
            return [...prev, newMsg];
          });
          setTimeout(scrollToBottom, 100);
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'chat_messages',
          filter: `workspace_id=eq.${workspace.id}`,
        },
        (payload) => {
          const deletedId = (payload.old as ChatMessage).id;
          setMessages((prev) => prev.filter((m) => m.id !== deletedId));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [workspace, scrollToBottom]);

  async function handleSend() {
    if (!input.trim() || !workspace) return;
    setSending(true);
    setError('');

    const { data: { user } } = await supabase.auth.getUser();
    const senderId = user?.id ?? null;

    const { error: err } = await supabase.from('chat_messages').insert({
      workspace_id: workspace.id,
      sender_id: senderId,
      sender_name: displayName ?? t('common.unknown'),
      sender_role: role ?? 'coordinator',
      message_text: input.trim(),
    });

    if (err) {
      setError(t('chat.errSendMessage'));
    } else {
      setInput('');
    }
    setSending(false);
  }

  async function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file || !workspace) return;

    // 10MB limit
    if (file.size > 10 * 1024 * 1024) {
      setError(t('chat.errFileSize'));
      e.target.value = '';
      return;
    }

    setUploading(true);
    setError('');

    try {
      const { data: { user } } = await supabase.auth.getUser();
      const senderId = user?.id ?? 'unknown';
      const ext = file.name.split('.').pop();
      const fileName = `${workspace.id}/${senderId}/${Date.now()}.${ext}`;

      const { error: uploadErr } = await supabase.storage
        .from('chat-files')
        .upload(fileName, file, { cacheControl: '3600', upsert: false });

      if (uploadErr) throw new Error(t('chat.errUpload'));

      const { data: urlData } = supabase.storage
        .from('chat-files')
        .getPublicUrl(fileName);

      const { error: msgErr } = await supabase.from('chat_messages').insert({
        workspace_id: workspace.id,
        sender_id: senderId,
        sender_name: displayName ?? t('common.unknown'),
        sender_role: role ?? 'coordinator',
        message_text: null,
        file_url: urlData.publicUrl,
        file_name: file.name,
        file_size: file.size,
      });

      if (msgErr) throw new Error(t('chat.errFileMessage'));
    } catch (err) {
      setError(err instanceof Error ? err.message : t('chat.errShareFile'));
    }

    setUploading(false);
    e.target.value = '';
  }

  async function handleDeleteMessage(msgId: string) {
    const { error: err } = await supabase
      .from('chat_messages')
      .delete()
      .eq('id', msgId);

    if (err) {
      setError(t('chat.errDelete'));
    } else {
      setMessages((prev) => prev.filter((m) => m.id !== msgId));
    }
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 size={28} className="animate-spin text-amber-500" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] lg:h-[calc(100vh-4rem)] max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-lg">
            <MessageCircle size={22} className="text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white">{t('chat.title')}</h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">{t('chat.pastorsCoordinators')}</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
          <Users size={14} />
          {participants.length} {participants.length === 1 ? t('common.member_single') : t('common.members_plural')}
        </div>
      </div>

      {/* Participants bar */}
      {participants.length > 0 && (
        <div className="flex items-center gap-2 mb-3 overflow-x-auto pb-2 px-1">
          {participants.map((p) => (
            <div
              key={p.id}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-700/50 border border-slate-200 dark:border-slate-600 flex-shrink-0"
            >
              <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                p.role === 'pastor'
                  ? 'bg-gradient-to-br from-amber-400 to-amber-600 text-slate-900'
                  : 'bg-gradient-to-br from-emerald-400 to-emerald-600 text-white'
              }`}>
                {p.display_name[0]?.toUpperCase()}
              </div>
              <span className="text-xs font-medium text-slate-700 dark:text-slate-300 whitespace-nowrap">
                {p.display_name}
              </span>
              {p.role === 'pastor' && <Crown size={11} className="text-amber-500" />}
            </div>
          ))}
        </div>
      )}

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-4 space-y-3 min-h-0">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center py-12">
            <div className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-700 flex items-center justify-center mb-3">
              <MessageCircle size={28} className="text-slate-400" />
            </div>
            <p className="text-sm font-medium text-slate-600 dark:text-slate-300">{t('chat.noMessages')}</p>
            <p className="text-xs text-slate-400 mt-1">{t('chat.startConversation')}</p>
          </div>
        )}

        {messages.map((msg) => {
          const isOwn = msg.sender_name === displayName;
          return (
            <div
              key={msg.id}
              className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[75%] group ${isOwn ? 'items-end' : 'items-start'} flex flex-col`}>
                {!isOwn && (
                  <div className="flex items-center gap-1.5 mb-1 ml-1">
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      msg.sender_role === 'pastor'
                        ? 'bg-gradient-to-br from-amber-400 to-amber-600 text-slate-900'
                        : 'bg-gradient-to-br from-emerald-400 to-emerald-600 text-white'
                    }`}>
                      {msg.sender_name[0]?.toUpperCase()}
                    </div>
                    <span className="text-xs font-medium text-slate-600 dark:text-slate-300">
                      {msg.sender_name}
                    </span>
                    {msg.sender_role === 'pastor' && <Crown size={10} className="text-amber-500" />}
                  </div>
                )}

                <div
                  className={`rounded-2xl px-3.5 py-2.5 ${
                    isOwn
                      ? 'bg-gradient-to-br from-amber-500 to-amber-600 text-white rounded-br-md'
                      : msg.sender_role === 'pastor'
                        ? 'bg-amber-50 dark:bg-amber-500/10 text-slate-800 dark:text-slate-100 rounded-bl-md border border-amber-200/50 dark:border-amber-500/20'
                        : 'bg-slate-100 dark:bg-slate-700/50 text-slate-800 dark:text-slate-100 rounded-bl-md'
                  }`}
                >
                  {msg.message_text && (
                    <p className="text-sm whitespace-pre-wrap break-words">{msg.message_text}</p>
                  )}

                  {msg.file_url && (
                    <a
                      href={msg.file_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      download={msg.file_name ?? undefined}
                      className={`flex items-center gap-3 mt-1 p-2.5 rounded-xl transition-all ${
                        isOwn
                          ? 'bg-white/20 hover:bg-white/30'
                          : 'bg-white dark:bg-slate-600/50 hover:bg-slate-50 dark:hover:bg-slate-600'
                      }`}
                    >
                      {(() => {
                        const FileIcon = getFileIcon(msg.file_name);
                        return <FileIcon size={24} className={isOwn ? 'text-white' : 'text-slate-500 dark:text-slate-300'} />;
                      })()}
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-medium truncate ${isOwn ? 'text-white' : 'text-slate-700 dark:text-slate-200'}`}>
                          {msg.file_name}
                        </p>
                        {msg.file_size && (
                          <p className={`text-xs ${isOwn ? 'text-white/70' : 'text-slate-400'}`}>
                            {formatFileSize(msg.file_size)}
                          </p>
                        )}
                      </div>
                      <Download size={18} className={isOwn ? 'text-white' : 'text-slate-400'} />
                    </a>
                  )}
                </div>

                <div className={`flex items-center gap-2 mt-1 mx-1 ${isOwn ? 'flex-row-reverse' : ''}`}>
                  <span className="text-[10px] text-slate-400">{formatTime(msg.created_at)}</span>
                  {isOwn && (
                    <button
                      onClick={() => handleDeleteMessage(msg.id)}
                      className="text-[10px] text-slate-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-0.5"
                    >
                      <X size={10} /> {t('chat.delete')}
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Error */}
      {error && (
        <p className="text-sm text-rose-500 mt-2 px-1">{error}</p>
      )}

      {/* Input area */}
      <div className="mt-3 flex items-end gap-2">
        <input
          ref={fileInputRef}
          type="file"
          onChange={handleFileSelect}
          className="hidden"
          accept="image/*,.pdf,.doc,.docx,.txt,.csv,.xlsx,.ppt,.pptx,.zip"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="flex-shrink-0 w-11 h-11 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400 hover:text-amber-500 hover:border-amber-300 dark:hover:border-amber-500/40 transition-all disabled:opacity-50"
          title={t('chat.attachFile')}
        >
          {uploading ? <Loader2 size={20} className="animate-spin" /> : <Paperclip size={20} />}
        </button>

        <div className="flex-1 relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            rows={1}
            placeholder={t('chat.typeMessage')}
            className="w-full resize-none rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-4 py-3 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/40 focus:border-amber-400 max-h-32"
            style={{ minHeight: '44px' }}
          />
        </div>

        <button
          onClick={handleSend}
          disabled={sending || !input.trim()}
          className="flex-shrink-0 w-11 h-11 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-white hover:from-amber-600 hover:to-amber-700 disabled:opacity-50 transition-all shadow-lg shadow-amber-500/20"
          title={t('chat.sendMessage')}
        >
          {sending ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} />}
        </button>
      </div>

      <p className="text-[10px] text-slate-400 mt-2 px-1">
        {t('chat.enterHint')}
      </p>
    </div>
  );
}
