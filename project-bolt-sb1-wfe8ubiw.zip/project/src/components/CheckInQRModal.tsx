import { QRCodeSVG } from 'qrcode.react';
import { Modal } from '@/components/Modal';
import { Workspace } from '@/types';
import { Download, Copy, Check, Share2, ClipboardCheck } from 'lucide-react';
import { useState, useRef } from 'react';
import { useLanguage } from '@/context/LanguageContext';

interface CheckInQRModalProps {
  open: boolean;
  onClose: () => void;
  workspace: Workspace;
}

export function CheckInQRModal({ open, onClose, workspace }: CheckInQRModalProps) {
  const [copied, setCopied] = useState(false);
  const { t } = useLanguage();
  const qrWrapperRef = useRef<HTMLDivElement>(null);

  const checkinUrl = `${window.location.origin}?checkin=${workspace.join_code}`;

  function copyLink() {
    navigator.clipboard.writeText(checkinUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function downloadQR() {
    const svg = qrWrapperRef.current?.querySelector('svg');
    if (!svg) return;

    const svgString = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement('canvas');
    const size = 400;
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, size, size);

    const img = new Image();
    const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    img.onload = () => {
      ctx.drawImage(img, 0, 0, size, size);
      URL.revokeObjectURL(url);
      canvas.toBlob((blob) => {
        if (!blob) return;
        const link = document.createElement('a');
        link.download = `glory-center-checkin-${workspace.join_code}.png`;
        link.href = URL.createObjectURL(blob);
        link.click();
        URL.revokeObjectURL(link.href);
      });
    };
    img.src = url;
  }

  async function shareLink() {
    if (navigator.share) {
      try {
        await navigator.share({
          title: t('checkinQR.shareTitle', { name: workspace.name }),
          text: t('checkinQR.shareText', { name: workspace.name }),
          url: checkinUrl,
        });
      } catch {
        // cancelled
      }
    } else {
      copyLink();
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={t('checkinQR.title')} size="sm">
      <div className="flex flex-col items-center space-y-5">
        <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400">
          <ClipboardCheck size={18} />
          <p className="text-sm font-medium">{t('checkinQR.displayForMembers')}</p>
        </div>

        <p className="text-sm text-slate-500 dark:text-slate-400 text-center">
          {t('checkinQR.desc')}
        </p>

        {/* QR Code */}
        <div ref={qrWrapperRef} className="p-5 bg-white rounded-2xl border-2 border-slate-200 shadow-sm">
          <QRCodeSVG
            value={checkinUrl}
            size={220}
            level="M"
            includeMargin={false}
            fgColor="#1e293b"
            bgColor="#ffffff"
          />
        </div>

        {/* Actions */}
        <div className="flex gap-3 w-full pt-2">
          <button
            onClick={downloadQR}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors"
          >
            <Download size={16} /> {t('checkinQR.download')}
          </button>
          <button
            onClick={shareLink}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium text-white bg-amber-500 hover:bg-amber-600 transition-colors"
          >
            <Share2 size={16} /> {t('checkinQR.share')}
          </button>
        </div>

        <button
          onClick={copyLink}
          className="text-xs text-slate-400 hover:text-amber-500 flex items-center gap-1.5 transition-colors"
        >
          {copied ? <Check size={13} /> : <Copy size={13} />}
          {copied ? t('checkinQR.linkCopied') : t('checkinQR.copyLink')}
        </button>
      </div>
    </Modal>
  );
}
