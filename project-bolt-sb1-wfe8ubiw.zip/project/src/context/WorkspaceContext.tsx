import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Workspace, WorkspaceMember, SubscriptionStatus } from '@/types';

type Role = 'pastor' | 'member' | 'coordinator';

interface WorkspaceState {
  workspace: Workspace | null;
  role: Role | null;
  displayName: string | null;
  ownerEmail: string | null;
  hasFreeAccess: boolean;
  trialDaysLeft: number;
  isTrialActive: boolean;
  hasActiveSubscription: boolean;
  canUseApp: boolean;
  loading: boolean;
}

interface WorkspaceContextValue extends WorkspaceState {
  createWorkspace: (name: string, pastorName: string, ownerEmail: string, description?: string) => Promise<Workspace>;
  joinWorkspace: (joinCode: string, displayName: string) => Promise<Workspace | null>;
  signUpPastor: (email: string, password: string, churchName: string, pastorName: string) => Promise<void>;
  signInPastor: (email: string, password: string) => Promise<void>;
  signUpCoordinator: (email: string, password: string, joinCode: string, displayName: string) => Promise<void>;
  signInCoordinator: (email: string, password: string) => Promise<void>;
  signOutPastor: () => Promise<void>;
  leaveWorkspace: () => void;
  refreshWorkspace: () => Promise<void>;
  createCheckoutSession: () => Promise<void>;
}

const WorkspaceContext = createContext<WorkspaceContextValue | undefined>(undefined);

const STORAGE_KEY = 'glory-workspace-session';

interface StoredSession {
  workspaceId: string;
  role: Role;
  displayName: string;
  ownerEmail: string | null;
}

function computeTrialDaysLeft(trialEnd: string): number {
  const end = new Date(trialEnd).getTime();
  const now = Date.now();
  return Math.max(0, Math.ceil((end - now) / (1000 * 60 * 60 * 24)));
}

function computeHasActiveSubscription(status: SubscriptionStatus, subEnd: string | null): boolean {
  if (status === 'active') return true;
  if (status === 'past_due' || status === 'canceled') {
    if (!subEnd) return false;
    return new Date(subEnd).getTime() > Date.now();
  }
  return false;
}

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<WorkspaceState>({
    workspace: null,
    role: null,
    displayName: null,
    ownerEmail: null,
    hasFreeAccess: false,
    trialDaysLeft: 0,
    isTrialActive: false,
    hasActiveSubscription: false,
    canUseApp: false,
    loading: true,
  });

  const checkFreeAccess = useCallback(async (email: string | null): Promise<boolean> => {
    if (!email) return false;
    const { data } = await supabase
      .from('free_access_emails')
      .select('email')
      .ilike('email', email.trim())
      .maybeSingle();
    return !!data;
  }, []);

  const buildState = useCallback((
    ws: Workspace,
    role: Role,
    displayName: string,
    ownerEmail: string | null,
    freeAccess: boolean
  ): WorkspaceState => {
    const trialDaysLeft = computeTrialDaysLeft(ws.trial_end);
    const isTrialActive = trialDaysLeft > 0;
    const hasActiveSubscription = computeHasActiveSubscription(ws.subscription_status, ws.subscription_end);
    const canUseApp = freeAccess || isTrialActive || hasActiveSubscription;

    return {
      workspace: ws,
      role,
      displayName,
      ownerEmail,
      hasFreeAccess: freeAccess,
      trialDaysLeft,
      isTrialActive,
      hasActiveSubscription,
      canUseApp,
      loading: false,
    };
  }, []);

  const loadWorkspaceByOwnerUserId = useCallback(async (userId: string): Promise<Workspace | null> => {
    const { data } = await supabase
      .from('workspaces')
      .select('*')
      .eq('owner_user_id', userId)
      .maybeSingle();
    return (data as Workspace) ?? null;
  }, []);

  const loadWorkspace = useCallback(async (session: StoredSession) => {
    const { data } = await supabase
      .from('workspaces')
      .select('*')
      .eq('id', session.workspaceId)
      .maybeSingle();

    if (data) {
      const ws = data as Workspace;
      const freeAccess = await checkFreeAccess(session.ownerEmail ?? ws.owner_email);
      setState(buildState(ws, session.role, session.displayName, session.ownerEmail ?? ws.owner_email, freeAccess));
    } else {
      localStorage.removeItem(STORAGE_KEY);
      setState({
        workspace: null, role: null, displayName: null, ownerEmail: null,
        hasFreeAccess: false, trialDaysLeft: 0, isTrialActive: false,
        hasActiveSubscription: false, canUseApp: false, loading: false,
      });
    }
  }, [checkFreeAccess, buildState]);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const session = JSON.parse(stored) as StoredSession;
        loadWorkspace(session);
      } catch {
        localStorage.removeItem(STORAGE_KEY);
        setState({
          workspace: null, role: null, displayName: null, ownerEmail: null,
          hasFreeAccess: false, trialDaysLeft: 0, isTrialActive: false,
          hasActiveSubscription: false, canUseApp: false, loading: false,
        });
      }
    } else {
      setState({
        workspace: null, role: null, displayName: null, ownerEmail: null,
        hasFreeAccess: false, trialDaysLeft: 0, isTrialActive: false,
        hasActiveSubscription: false, canUseApp: false, loading: false,
      });
    }
  }, [loadWorkspace]);

  const persistSession = (wsId: string, role: Role, name: string, email: string | null) => {
    const session: StoredSession = { workspaceId: wsId, role, displayName: name, ownerEmail: email };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(session));
  };

  const createWorkspace = async (
    name: string,
    pastorName: string,
    ownerEmail: string,
    description?: string
  ): Promise<Workspace> => {
    const { data: ws, error } = await supabase
      .from('workspaces')
      .insert({
        name: name.trim(),
        pastor_name: pastorName.trim(),
        description: description?.trim() || null,
        owner_email: ownerEmail.trim() || null,
        trial_start: new Date().toISOString(),
        trial_end: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        subscription_status: 'trial',
      })
      .select()
      .single();

    if (error || !ws) throw new Error(error?.message ?? 'Failed to create workspace');

    const newWorkspace = ws as Workspace;

    await supabase.from('workspace_members').insert({
      workspace_id: newWorkspace.id,
      display_name: pastorName.trim(),
      role: 'pastor',
    });

    const freeAccess = await checkFreeAccess(ownerEmail);
    persistSession(newWorkspace.id, 'pastor', pastorName.trim(), ownerEmail.trim() || null);
    setState(buildState(newWorkspace, 'pastor', pastorName.trim(), ownerEmail.trim() || null, freeAccess));

    return newWorkspace;
  };

  const joinWorkspace = async (joinCode: string, displayName: string): Promise<Workspace | null> => {
    const code = joinCode.trim().toUpperCase();
    const { data: ws, error } = await supabase
      .from('workspaces')
      .select('*')
      .eq('join_code', code)
      .maybeSingle();

    if (error || !ws) return null;

    const workspace = ws as Workspace;

    const { data: existing } = await supabase
      .from('workspace_members')
      .select('*')
      .eq('workspace_id', workspace.id)
      .eq('display_name', displayName.trim())
      .maybeSingle();

    if (!existing) {
      await supabase.from('workspace_members').insert({
        workspace_id: workspace.id,
        display_name: displayName.trim(),
        role: 'coordinator',
      });
    }

    const role = (existing?.role as Role) ?? 'coordinator';
    persistSession(workspace.id, role, displayName.trim(), null);
    setState(buildState(workspace, role, displayName.trim(), null, false));

    return workspace;
  };

  const signUpPastor = async (email: string, password: string, churchName: string, pastorName: string): Promise<void> => {
    // 1. Create auth account
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: email.trim().toLowerCase(),
      password,
    });

    if (authError) throw new Error(authError.message);
    if (!authData.user) throw new Error('Failed to create account');

    // 2. Create workspace linked to auth user
    const { data: ws, error: wsErr } = await supabase
      .from('workspaces')
      .insert({
        name: churchName.trim(),
        pastor_name: pastorName.trim(),
        description: null,
        owner_email: email.trim().toLowerCase(),
        owner_user_id: authData.user.id,
        trial_start: new Date().toISOString(),
        trial_end: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
        subscription_status: 'trial',
      })
      .select()
      .single();

    if (wsErr || !ws) throw new Error(wsErr?.message ?? 'Failed to create workspace');

    const newWorkspace = ws as Workspace;

    await supabase.from('workspace_members').insert({
      workspace_id: newWorkspace.id,
      display_name: pastorName.trim(),
      role: 'pastor',
    });

    const freeAccess = await checkFreeAccess(email);
    persistSession(newWorkspace.id, 'pastor', pastorName.trim(), email.trim().toLowerCase());
    setState(buildState(newWorkspace, 'pastor', pastorName.trim(), email.trim().toLowerCase(), freeAccess));
  };

  const loadWorkspaceByMemberUserId = useCallback(async (userId: string): Promise<{ ws: Workspace; role: Role; displayName: string } | null> => {
    const { data: member } = await supabase
      .from('workspace_members')
      .select('workspace_id, role, display_name')
      .eq('user_id', userId)
      .maybeSingle();
    if (!member) return null;
    const { data: wsData } = await supabase
      .from('workspaces')
      .select('*')
      .eq('id', member.workspace_id)
      .maybeSingle();
    if (!wsData) return null;
    return { ws: wsData as Workspace, role: member.role as Role, displayName: member.display_name };
  }, []);

  const linkPastorMemberToAuthUser = useCallback(async (userId: string, workspaceId: string) => {
    await supabase
      .from('workspace_members')
      .update({ user_id: userId })
      .eq('workspace_id', workspaceId)
      .eq('role', 'pastor')
      .is('user_id', null);
  }, []);

  const signInPastor = async (email: string, password: string): Promise<void> => {
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email: email.trim().toLowerCase(),
      password,
    });

    if (authError) throw new Error(authError.message);
    if (!authData.user) throw new Error('Login failed');

    const ws = await loadWorkspaceByOwnerUserId(authData.user.id);
    if (!ws) throw new Error('No workspace found for this account');

    await linkPastorMemberToAuthUser(authData.user.id, ws.id);

    const freeAccess = await checkFreeAccess(ws.owner_email);
    persistSession(ws.id, 'pastor', ws.pastor_name, ws.owner_email);
    setState(buildState(ws, 'pastor', ws.pastor_name, ws.owner_email, freeAccess));
  };

  const signUpCoordinator = async (email: string, password: string, joinCode: string, displayName: string): Promise<void> => {
    const code = joinCode.trim().toUpperCase();
    // 1. Look up workspace by join code
    const { data: wsData, error: wsErr } = await supabase
      .from('workspaces')
      .select('*')
      .eq('join_code', code)
      .maybeSingle();
    if (wsErr || !wsData) throw new Error('Invalid join code. Please check and try again.');
    const workspace = wsData as Workspace;

    // 2. Create auth account
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: email.trim().toLowerCase(),
      password,
    });
    if (authError) throw new Error(authError.message);
    if (!authData.user) throw new Error('Failed to create account');

    // 3. Insert or update workspace_members with user_id
    const { data: existing } = await supabase
      .from('workspace_members')
      .select('*')
      .eq('workspace_id', workspace.id)
      .eq('display_name', displayName.trim())
      .maybeSingle();

    if (existing) {
      await supabase
        .from('workspace_members')
        .update({ user_id: authData.user.id, email: email.trim().toLowerCase() })
        .eq('id', existing.id);
    } else {
      await supabase.from('workspace_members').insert({
        workspace_id: workspace.id,
        display_name: displayName.trim(),
        role: 'coordinator',
        user_id: authData.user.id,
        email: email.trim().toLowerCase(),
      });
    }

    persistSession(workspace.id, 'coordinator', displayName.trim(), email.trim().toLowerCase());
    setState(buildState(workspace, 'coordinator', displayName.trim(), email.trim().toLowerCase(), false));
  };

  const signInCoordinator = async (email: string, password: string): Promise<void> => {
    const { data: authData, error: authError } = await supabase.auth.signInWithPassword({
      email: email.trim().toLowerCase(),
      password,
    });
    if (authError) throw new Error(authError.message);
    if (!authData.user) throw new Error('Login failed');

    const result = await loadWorkspaceByMemberUserId(authData.user.id);
    if (!result) throw new Error('No workspace found for this account');

    const freeAccess = await checkFreeAccess(result.ws.owner_email);
    persistSession(result.ws.id, result.role, result.displayName, email.trim().toLowerCase());
    setState(buildState(result.ws, result.role, result.displayName, email.trim().toLowerCase(), freeAccess));
  };

  const signOutPastor = async (): Promise<void> => {
    await supabase.auth.signOut();
    leaveWorkspace();
  };

  // Listen for auth state changes (e.g. session restored on page reload)
  useEffect(() => {
    supabase.auth.onAuthStateChange((event, session) => {
      (async () => {
        if ((event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') && session?.user) {
          // Only auto-restore if we don't already have a workspace loaded
          const stored = localStorage.getItem(STORAGE_KEY);
          if (!stored && session.user.id) {
            // Try pastor first (owner_user_id), then coordinator (workspace_members.user_id)
            const ws = await loadWorkspaceByOwnerUserId(session.user.id);
            if (ws) {
              await linkPastorMemberToAuthUser(session.user.id, ws.id);
              const freeAccess = await checkFreeAccess(ws.owner_email);
              persistSession(ws.id, 'pastor', ws.pastor_name, ws.owner_email);
              setState(buildState(ws, 'pastor', ws.pastor_name, ws.owner_email, freeAccess));
            } else {
              const result = await loadWorkspaceByMemberUserId(session.user.id);
              if (result) {
                const freeAccess = await checkFreeAccess(result.ws.owner_email);
                persistSession(result.ws.id, result.role, result.displayName, null);
                setState(buildState(result.ws, result.role, result.displayName, null, freeAccess));
              }
            }
          }
        }
      })();
    });
  }, []);

  const leaveWorkspace = () => {
    localStorage.removeItem(STORAGE_KEY);
    setState({
      workspace: null, role: null, displayName: null, ownerEmail: null,
      hasFreeAccess: false, trialDaysLeft: 0, isTrialActive: false,
      hasActiveSubscription: false, canUseApp: false, loading: false,
    });
  };

  const refreshWorkspace = async () => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        const session = JSON.parse(stored) as StoredSession;
        await loadWorkspace(session);
      } catch {
        // ignore
      }
    }
  };

  const createCheckoutSession = async (): Promise<void> => {
    const { data: sessionData } = await supabase.auth.getSession();
    const accessToken = sessionData.session?.access_token;
    if (!accessToken) throw new Error('You must be signed in to subscribe. Please log out and sign back in.');

    const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-checkout`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error ?? 'Failed to start checkout');
    }
    const data = await res.json();
    if (data.url) {
      window.location.href = data.url;
    } else {
      throw new Error('Failed to get checkout URL');
    }
  };

  return (
    <WorkspaceContext.Provider value={{ ...state, createWorkspace, joinWorkspace, signUpPastor, signInPastor, signUpCoordinator, signInCoordinator, signOutPastor, leaveWorkspace, refreshWorkspace, createCheckoutSession }}>
      {children}
    </WorkspaceContext.Provider>
  );
}

export function useWorkspace() {
  const ctx = useContext(WorkspaceContext);
  if (!ctx) throw new Error('useWorkspace must be used within WorkspaceProvider');
  return ctx;
}
